rvertnet2
=========

A few of the next-gen functions for extracting and displaying data from the VertNet archives
