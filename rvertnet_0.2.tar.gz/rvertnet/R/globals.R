if(getRversion() >= "2.15.1")
  utils::globalVariables(c(
    'long',
    'lat',
    'group',
    'decimallongitude', 
    'decimallatitude', 
    'scientificname'))